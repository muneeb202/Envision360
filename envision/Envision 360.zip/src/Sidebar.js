// Sidebar.js

import React from 'react';

const Sidebar = () => {
  return (
    <div className="sidebar">
      {/* Add your sidebar content here */}
      <p>Sidebar Content</p>
    </div>
  );
};

export default Sidebar;
